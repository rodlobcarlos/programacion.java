package rodriguez_carlos_Examen2;

public enum TipoVuelo {
	LOW_COST, NORMAL, EXPRESS
}
