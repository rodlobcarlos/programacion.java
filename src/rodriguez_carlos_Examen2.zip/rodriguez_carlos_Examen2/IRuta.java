package rodriguez_carlos_Examen2;

public interface IRuta {
	double getCoste();
	String getTipoRuta();
}
