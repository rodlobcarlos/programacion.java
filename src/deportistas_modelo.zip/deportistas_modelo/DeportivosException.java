package deportistas_modelo;

public class DeportivosException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DeportivosException(String mensaje) {
		super(mensaje);
	}
}
