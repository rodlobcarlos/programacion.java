package biblioteca_modelo;

public enum EstadoLibro {
	PRESTADO, LIBRE
}
