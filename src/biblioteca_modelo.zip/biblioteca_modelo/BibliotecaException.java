package biblioteca_modelo;

public class BibliotecaException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BibliotecaException(String mesaje) {
		super(mesaje);
	}
	
	
}
