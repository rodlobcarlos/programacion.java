package rodriguez_carlos2;

public enum TipoDieta {
	VEGETARIANO, VEGANO, SIN_GLUTEN, SIN_LACTOSA
}