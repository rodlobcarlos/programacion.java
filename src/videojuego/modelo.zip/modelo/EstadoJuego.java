package videojuego.modelo;

public enum EstadoJuego {
    EN_REVISION, APROBADO, RECHAZADO
}
