package videojuego.modelo;

public enum GeneroJuego {
    AVENTURA, PUZLE, ACCION, SIMULADOR, DEPORTES
}
