package excepcion;

public class GestionaException {

	public static boolean m1() throws NullPointerException {
		
		throw new NullPointerException("Genero NullPointer");
	}
}
