package excepcion;

public class GestionaException3 {

	Scanner scanner = 
}
