package rodriguez_carlos_Examen1;

public enum TipoPremiun {
	PREMIUN, PREMIUN_VIP
}
