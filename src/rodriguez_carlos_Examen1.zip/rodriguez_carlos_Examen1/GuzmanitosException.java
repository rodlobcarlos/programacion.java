package rodriguez_carlos_Examen1;

public class GuzmanitosException extends Exception{

	public GuzmanitosException(String mensaje)  throws GuzmanitosException{
		super(mensaje);
	}
}
