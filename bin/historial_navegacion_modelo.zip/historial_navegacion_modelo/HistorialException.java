package historial_navegacion_modelo;

public class HistorialException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HistorialException(String mensaje) {
		super(mensaje);
	}
}
