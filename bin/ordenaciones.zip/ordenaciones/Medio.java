package ordenaciones;

public enum Medio {

	AGUA, AIRE, TIERRA
}
