package ordenaciones;

public enum ClasificacionComida {

	HERVIBOROS, CARNIVOROS, OMNIVOROS
}
