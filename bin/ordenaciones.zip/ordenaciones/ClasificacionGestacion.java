package ordenaciones;

public enum ClasificacionGestacion {

	OVIPAROS, OVOVIVIPAROS, VIVIPAROS
}
